function [ ke ] = ke_beam(nodalcoords,parameterlist) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Finite Element Reliability using Matlab, FERUM, Version 3.0       %
%                                                                   %
% This program is free software; you can redistribute it and/or     %
% modify it under the terms of the GNU General Public License       %
% as published by the Free Software Foundation; either version 2    %
% of the License, or (at your option) any later version.            %
%                                                                   %
% This program is distributed in the hope that it will be useful,   %
% but WITHOUT ANY WARRANTY; without even the implied warranty of    %
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     %
% GNU General Public License for more details.                      %
%                                                                   %
% A copy of the GNU General Public License is found in the file     %
% <gpl.txt> following this collection of program files.             %
%                                                                   %
% Developed under the sponsorship of the Pacific                    %
% Earthquake Engineering (PEER) Center.                             %
%                                                                   %
% For more information, visit: http://www.ce.berkeley.edu/~haukaas  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


E = parameterlist(1);
I = parameterlist(2);
A = parameterlist(3);

% Element length and angle
delta_x = nodalcoords(3) - nodalcoords(1);
delta_y = nodalcoords(4) - nodalcoords(2);
L = sqrt( delta_x^2 + delta_y^2 );
if delta_x == 0    % If element is vertical
   if delta_y < 0  % If element is vertical and upside down
      theta = -pi/2;
   else
      theta = pi/2;
   end
else
   theta = atan( delta_y / delta_x );
end

% Element stiffness matrix in local coordinates
ke_local = [   E*A/L  0           0             -E*A/L   0             0          ;
               0      12*E*I/L^3  6*E*I/L^2      0       -12*E*I/L^3   6*E*I/L^2  ;
               0      6*E*I/L^2   4*E*I/L        0       -6*E*I/L^2    2*E*I/L    ;
               -E*A/L 0           0              E*A/L   0             0          ;
               0      -12*E*I/L^3 -6*E*I/L^2     0       12*E*I/L^3    -6*E*I/L^2 ;    
               0      6*E*I/L^2   2*E*I/L        0       -6*E*I/L^2    4*E*I/L    ];
        
% Transformation to global coordinate system
c = cos(theta);
s = sin(theta);
T = [ c  s  0     0  0  0 ;
     -s  c  0     0  0  0 ;
      0  0  1     0  0  0 ;
      0  0  0     c  s  0 ;
      0  0  0    -s  c  0 ;
      0  0  0     0  0  1 ];
     
ke = T' * ke_local * T;
